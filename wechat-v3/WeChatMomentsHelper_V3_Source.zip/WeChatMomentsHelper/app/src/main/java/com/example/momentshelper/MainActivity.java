package com.example.momentshelper;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    private TextView preview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.txtStatus);
        preview = findViewById(R.id.txtPreview);
        Button btnAccessibility = findViewById(R.id.btnAccessibility);
        Button btnOverlay = findViewById(R.id.btnOverlay);
        Button btnOpenWeChat = findViewById(R.id.btnOpenWeChat);

        btnAccessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        btnOverlay.setOnClickListener(v -> {
            boolean enabled = !getSharedPreferences("helper", MODE_PRIVATE).getBoolean("overlay_enabled", true);
            getSharedPreferences("helper", MODE_PRIVATE).edit().putBoolean("overlay_enabled", enabled).apply();
            status.setText(enabled ? "状态：微信悬浮控制条已启用" : "状态：微信悬浮控制条已关闭");
            Toast.makeText(this, "设置已保存；重新进入微信后生效", Toast.LENGTH_SHORT).show();
        });

        btnOpenWeChat.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.tencent.mm");
            if (launch == null) {
                Toast.makeText(this, "未检测到微信", Toast.LENGTH_LONG).show();
                return;
            }
            startActivity(launch);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String last = getSharedPreferences("helper", MODE_PRIVATE).getString("last_text", "");
        preview.setText(TextUtils.isEmpty(last) ? "尚未提取内容" : last);

        String wx = "未检测到微信";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo("com.tencent.mm", 0);
            wx = "微信版本：" + pi.versionName + ("8.0.79".equals(pi.versionName) ? "（已针对性适配）" : "（可尝试使用）");
        } catch (Exception ignored) { }
        status.setText("状态：" + wx);
    }
}
