package com.example.momentshelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class WeChatAccessibilityService extends AccessibilityService {
    private static final String WECHAT = "com.tencent.mm";
    private final Handler handler = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private long lastEventAt = 0L;

    private boolean publishing = false;
    private int publishStep = 0;
    private String pendingText = "";
    private long publishStartedAt = 0L;

    private final Set<String> noise = new LinkedHashSet<>(Arrays.asList(
            "微信", "通讯录", "发现", "我", "朋友圈", "视频号", "搜一搜", "扫一扫",
            "点赞", "评论", "详情", "返回", "更多", "发送", "发表", "取消", "完成",
            "全文", "收起", "不感兴趣", "设置朋友权限", "投诉", "删除", "保存图片",
            "赞", "私密", "谁可以看", "提醒谁看"
    ));

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null || !WECHAT.contentEquals(event.getPackageName())) {
            removeOverlay();
            return;
        }

        if (getSharedPreferences("helper", MODE_PRIVATE).getBoolean("overlay_enabled", true)) {
            ensureOverlay();
        } else {
            removeOverlay();
        }

        long now = System.currentTimeMillis();
        if (now - lastEventAt < 220) return;
        lastEventAt = now;

        if (publishing) handler.postDelayed(this::advancePublishFlow, 220);
    }

    private void ensureOverlay() {
        if (overlay != null || wm == null) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE18202B);
        bg.setCornerRadius(dp(16));
        box.setBackground(bg);

        overlayStatus = new TextView(this);
        overlayStatus.setText("朋友圈助手 V3 · 微信8.0.79");
        overlayStatus.setTextColor(0xFFFFFFFF);
        overlayStatus.setTextSize(12);
        box.addView(overlayStatus);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button capture = smallButton("克隆当前");
        capture.setOnClickListener(v -> captureCurrent());
        row.addView(capture, new LinearLayout.LayoutParams(dp(102), dp(46)));

        Button publish = smallButton("去发布");
        publish.setOnClickListener(v -> startPublish());
        row.addView(publish, new LinearLayout.LayoutParams(dp(86), dp(46)));

        Button stop = smallButton("停止");
        stop.setOnClickListener(v -> stopAutomation("已停止"));
        row.addView(stop, new LinearLayout.LayoutParams(dp(72), dp(46)));

        box.addView(row);
        overlay = box;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(8);
        lp.y = dp(110);

        final float[] down = new float[2];
        final int[] start = new int[2];
        box.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                down[0] = e.getRawX();
                down[1] = e.getRawY();
                start[0] = lp.x;
                start[1] = lp.y;
                return false;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float dx = down[0] - e.getRawX();
                float dy = e.getRawY() - down[1];
                if (Math.abs(dx) + Math.abs(dy) > dp(8)) {
                    lp.x = Math.max(0, start[0] + (int) dx);
                    lp.y = Math.max(0, start[1] + (int) dy);
                    try { wm.updateViewLayout(box, lp); } catch (Exception ignored) { }
                }
            }
            return false;
        });

        try { wm.addView(box, lp); } catch (Exception ignored) { overlay = null; }
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void removeOverlay() {
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
        }
        overlay = null;
        overlayStatus = null;
    }

    private void captureCurrent() {
        stopAutomation(null);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            toast("当前页面暂时无法读取");
            return;
        }

        List<NodeText> visible = new ArrayList<>();
        collectNodeText(root, visible, 0);
        if (visible.isEmpty()) {
            toast("没有识别到可用内容");
            return;
        }

        int screenH = getResources().getDisplayMetrics().heightPixels;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int centerY = screenH / 2;

        NodeText anchor = null;
        double best = Double.MAX_VALUE;
        for (NodeText item : visible) {
            if (!isCandidate(item.text)) continue;
            int cy = item.bounds.centerY();
            int centerPenalty = Math.abs(cy - centerY);
            int lengthBonus = Math.min(300, item.text.length() * 3);
            double score = centerPenalty - lengthBonus;
            if (score < best) {
                best = score;
                anchor = item;
            }
        }

        if (anchor == null) {
            toast("请把要克隆的那条朋友圈正文移动到屏幕中间");
            return;
        }

        int bandTop = Math.max(0, anchor.bounds.top - dp(180));
        int bandBottom = Math.min(screenH, anchor.bounds.bottom + dp(260));
        List<NodeText> cardLines = new ArrayList<>();
        for (NodeText item : visible) {
            if (!isCandidate(item.text)) continue;
            if (item.bounds.width() <= 0 || item.bounds.height() <= 0) continue;
            if (item.bounds.right < screenW * 0.10f) continue;
            int cy = item.bounds.centerY();
            if (cy >= bandTop && cy <= bandBottom) cardLines.add(item);
        }

        Collections.sort(cardLines, Comparator
                .comparingInt((NodeText n) -> n.bounds.top)
                .thenComparingInt(n -> n.bounds.left));

        LinkedHashSet<String> ordered = new LinkedHashSet<>();
        for (NodeText item : cardLines) {
            String s = normalize(item.text);
            if (isCandidate(s)) ordered.add(s);
        }

        StringBuilder sb = new StringBuilder();
        for (String s : ordered) {
            if (looksLikeNicknameOnly(s) && sb.length() == 0) continue;
            if (sb.length() > 0) sb.append("\n");
            sb.append(s);
            if (sb.length() >= 1800) break;
        }
        String text = sb.toString().trim();

        if (text.isEmpty()) {
            toast("没有提取到正文，请把目标朋友圈完整显示在屏幕中间");
            return;
        }

        String old = getSharedPreferences("helper", MODE_PRIVATE).getString("last_text", "");
        String oldHash = getSharedPreferences("helper", MODE_PRIVATE).getString("last_hash", "");
        String newHash = Integer.toHexString(normalizeForHash(text).hashCode());
        if (newHash.equals(oldHash) || normalizeForHash(text).equals(normalizeForHash(old))) {
            setOverlayStatus("已提取（重复内容）");
            toast("这条内容已经提取过了");
            return;
        }

        getSharedPreferences("helper", MODE_PRIVATE).edit()
                .putString("last_hash", newHash)
                .apply();
        saveAndCopy(text);
        setOverlayStatus("已提取 · 可点“去发布”");
        toast("已提取当前朋友圈正文并复制");
    }

    private void startPublish() {
        pendingText = getSharedPreferences("helper", MODE_PRIVATE).getString("last_text", "");
        if (pendingText.trim().isEmpty()) {
            toast("请先点“克隆当前”");
            return;
        }

        saveAndCopy(pendingText);
        publishing = true;
        publishStep = 0;
        publishStartedAt = System.currentTimeMillis();
        setOverlayStatus("正在进入朋友圈发布页…");

        Intent launch = getPackageManager().getLaunchIntentForPackage(WECHAT);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        }
        handler.postDelayed(this::advancePublishFlow, 650);
    }

    private void advancePublishFlow() {
        if (!publishing) return;
        if (System.currentTimeMillis() - publishStartedAt > 20000L) {
            stopAutomation("超时，正文已复制；请手动进入发布页");
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // Once the editor is present, fill text and stop. Final publish always remains manual.
        if (findEditableAndSet(root, pendingText)) {
            publishing = false;
            publishStep = 9;
            setOverlayStatus("正文已填入 · 请确认后手动发表");
            toast("正文已填入，请检查后手动点击“发表”");
            return;
        }

        if (publishStep <= 0) {
            AccessibilityNodeInfo discover = findClickable(root, "发现");
            if (discover != null && clickNode(discover)) {
                publishStep = 1;
                handler.postDelayed(this::advancePublishFlow, 550);
                return;
            }
            publishStep = 1;
        }

        if (publishStep <= 1) {
            AccessibilityNodeInfo moments = findClickable(root, "朋友圈");
            if (moments != null && clickNode(moments)) {
                publishStep = 2;
                handler.postDelayed(this::advancePublishFlow, 750);
                return;
            }
        }

        if (publishStep <= 2 && isLikelyMomentsPage(root)) {
            AccessibilityNodeInfo camera = findByAny(root, Arrays.asList(
                    "拍照分享", "相机", "发表朋友圈", "发布朋友圈", "拍摄", "从相册选择"
            ));
            if (camera != null) {
                AccessibilityNodeInfo target = clickableParent(camera);
                if (target != null) {
                    boolean ok = target.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK);
                    if (!ok) ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if (ok) {
                        publishStep = 3;
                        handler.postDelayed(this::advancePublishFlow, 650);
                        return;
                    }
                }
            }

            // WeChat 8.0.79 fallback: long press top-right camera area when accessibility label is missing.
            publishStep = 3;
            longPressTopRightCamera();
            handler.postDelayed(this::advancePublishFlow, 900);
            return;
        }

        setOverlayStatus("正文已复制 · 如未自动进入，请手动打开朋友圈发布页");
    }

    private void longPressTopRightCamera() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int x = w - dp(38);
        int y = dp(58);
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 850);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        try { dispatchGesture(gesture, null, null); } catch (Exception ignored) { }
    }

    private boolean isLikelyMomentsPage(AccessibilityNodeInfo root) {
        return findByAny(root, Arrays.asList("朋友圈")) != null;
    }

    private boolean findEditableAndSet(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        if (node.isEditable() || "android.widget.EditText".contentEquals(node.getClassName())) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true;

            saveAndCopy(text);
            try {
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                if (node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return true;
            } catch (Exception ignored) { }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo c = node.getChild(i);
            if (findEditableAndSet(c, text)) return true;
        }
        return false;
    }

    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo root, String value) {
        AccessibilityNodeInfo n = findByAny(root, Arrays.asList(value));
        return clickableParent(n);
    }

    private AccessibilityNodeInfo findByAny(AccessibilityNodeInfo node, List<String> values) {
        if (node == null) return null;
        String t = node.getText() == null ? "" : node.getText().toString();
        String d = node.getContentDescription() == null ? "" : node.getContentDescription().toString();
        for (String v : values) {
            if (v.equals(t) || v.equals(d) || t.contains(v) || d.contains(v)) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findByAny(node.getChild(i), values);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo clickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        for (int i = 0; cur != null && i < 7; i++) {
            if (cur.isClickable() || cur.isLongClickable()) return cur;
            cur = cur.getParent();
        }
        return node;
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        if (node == null) return false;
        AccessibilityNodeInfo target = clickableParent(node);
        return target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private void collectNodeText(AccessibilityNodeInfo node, List<NodeText> out, int depth) {
        if (node == null || depth > 50) return;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if (text != null && text.length() > 0) out.add(new NodeText(text.toString(), r));
        if (desc != null && desc.length() > 0 && (text == null || !desc.toString().equals(text.toString()))) {
            out.add(new NodeText(desc.toString(), r));
        }
        for (int i = 0; i < node.getChildCount(); i++) collectNodeText(node.getChild(i), out, depth + 1);
    }

    private boolean isCandidate(String raw) {
        String s = normalize(raw);
        if (s.length() < 2 || s.length() > 1200) return false;
        if (noise.contains(s)) return false;
        if (s.matches("^\\d{1,2}:\\d{2}$")) return false;
        if (s.matches("^\\d+[分小天月年].*$")) return false;
        if (s.matches("^昨天.*$|^今天.*$|^刚刚$")) return false;
        if (s.matches("^[·•…\\-_=+]+$")) return false;
        return true;
    }

    private boolean looksLikeNicknameOnly(String s) {
        return s.length() <= 10 && !s.contains(" ") && !s.contains("，") && !s.contains("。") && !s.contains("！") && !s.contains("？");
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.replace('\u00A0', ' ').replaceAll("[\\t\\r ]+", " ").trim();
    }

    private String normalizeForHash(String s) {
        return normalize(s).replaceAll("\\s+", "");
    }

    private void saveAndCopy(String text) {
        getSharedPreferences("helper", MODE_PRIVATE).edit().putString("last_text", text).apply();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("朋友圈正文", text));
    }

    private void stopAutomation(String status) {
        publishing = false;
        publishStep = 0;
        handler.removeCallbacksAndMessages(null);
        if (status != null) {
            setOverlayStatus(status);
            toast(status);
        }
    }

    private void setOverlayStatus(String text) {
        if (overlayStatus != null) overlayStatus.setText(text);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        stopAutomation(null);
        removeOverlay();
        super.onDestroy();
    }

    private static class NodeText {
        final String text;
        final Rect bounds;
        NodeText(String text, Rect bounds) {
            this.text = text;
            this.bounds = new Rect(bounds);
        }
    }
}
