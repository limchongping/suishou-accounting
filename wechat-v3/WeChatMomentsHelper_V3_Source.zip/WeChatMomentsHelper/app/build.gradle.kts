plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.momentshelper"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.momentshelper"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0-wx8079"
    }
}
